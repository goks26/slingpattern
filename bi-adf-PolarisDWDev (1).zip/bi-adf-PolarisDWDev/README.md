# bi-adf
A repository for the BI team to manage Azure Data Factory.
